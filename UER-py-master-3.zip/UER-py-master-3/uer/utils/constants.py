# Special token words.
CLS_TOKEN = "[CLS]"
SEP_TOKEN = "[SEP]"
MASK_TOKEN = "[MASK]"

# Special token words.
PAD_ID = 0
